package Pieces;

import com.company.Piece;

public class Queen extends Piece {
    @Override
    public boolean legalMove() {
        if((coordX == newX && newY <= 8) || (coordY == newY && newX <= 8) || (newY-coordY==newX-coordX)||(coordX+coordY==newX+newY))
            return true;
        else return false;
    }
}
