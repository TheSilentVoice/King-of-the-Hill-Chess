package com.company;

public abstract class Piece {

    public static int coordX;
    public static int coordY;

    public static int newX;
    public static int newY;


    public abstract boolean legalMove();

}

