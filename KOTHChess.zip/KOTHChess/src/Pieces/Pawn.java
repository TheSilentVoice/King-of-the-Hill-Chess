package Pieces;

import com.company.Piece;

public class Pawn extends Piece {

    @Override
    public boolean legalMove() {
        if ((newY == coordY) || (newX == (coordX + 1)))
            return true;
        else
            return false;
    }

}
