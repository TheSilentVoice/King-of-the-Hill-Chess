package Pieces;

import com.company.Piece;

public class Rook extends Piece {

    @Override
    public boolean legalMove() {
        if ((coordX == newX && newY <= 8) || (coordY == newY && newX <= 8))
            return true;
        return false;
    }
}
