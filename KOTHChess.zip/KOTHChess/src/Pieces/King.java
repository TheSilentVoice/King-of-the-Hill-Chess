package Pieces;

import com.company.Piece;

public class King extends Piece {
    @Override
    public boolean legalMove() {
        if((-1<=newX-coordX && newX-coordX<=1)&&(-1<=newY-coordY && newY-coordY<=1))
            return true;
        else return false;
    }
}
