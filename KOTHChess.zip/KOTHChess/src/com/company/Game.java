package com.company;


import java.util.Scanner;

public class Game {
    public static int menucontrol;

    public static void menu() {
        System.out.println("Welcome to King of the Hill Chess!");
        System.out.println("To choose a menu option, write the corresponding command.");
        System.out.println("1) Play");
        System.out.println("2) Read rules");
        System.out.println("3) Exit");
        int menuop;
        do {

            Scanner k = new Scanner(System.in);
            menuop = k.nextInt();
            switch (menuop) {
                case 1 -> { // more stuff to be added
                    gamestart();
                    /*ControlBoard b=new ControlBoard();
                    b.boardprint();*/
                    Turn t=new Turn();
                    t.turn();

                    /*Move m = new Move();
                    m.wmove();*/

                }
                case 2 -> {
                    System.out.println("King of the Hill chess is close to traditional Chess but it has a few changed rules.");
                    System.out.println("1) Pieces move just like in traditional Chess. White goes first as always.");
                    System.out.println("2) All pieces jump over other pieces.");
                    System.out.println("3) There is no Check / Check mate, the King can be captured like any other piece.");
                    System.out.println("4) Loosing the King means loosing the game.");
                    System.out.println("5) To win you need to reach the center of the map with your King.");
                    menu();
                }
                case 3 ->
                    System.exit(0);

                default -> {
                    System.out.println("Unrecognized input.");
                    menu();
                }

            }
        } while (menucontrol == 1);

    }
    public static void gamestart(){
        //Generating and printing the game board
        GraphicBoard newboard = new GraphicBoard();
        newboard.boardgen();
        newboard.boardprint();



    }

}
