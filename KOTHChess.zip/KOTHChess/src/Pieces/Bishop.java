package Pieces;

import com.company.Piece;

public class Bishop extends Piece {
    @Override
    public boolean legalMove() {
        if((newY-coordY==newX-coordX)||(coordX+coordY==newX+newY))
            return true;
        else return false;
    }
}
