package Pieces;

import com.company.Piece;

public class Knight extends Piece {
    @Override
    public boolean legalMove() {
        if ((newX == coordX + 1 && newY == coordY + 2) || (newX == coordX + 2 && newY == coordY + 1) ||
                (newX == coordX + 1 && newY == coordY - 2) || (newX == coordX + 2 && newY == coordY - 1) ||
                (newX == coordX - 1 && newY == coordY + 2) || (newX == coordX - 2 && newY == coordY + 1) ||
                (newX == coordX - 1 && newY == coordY - 2) || (newX == coordX - 2 && newY == coordY - 1))
            return true;
        else return false;
    }
}
