package com.company;

public class GraphicBoard {

    public static char[][] board = new char[10][10];

    public void boardgen() {
        for (int i = 1; i <= 8; i++)
            for (int j = 1; j <= 8; j++) {
                board[i][j] = ' ';
                ControlBoard.controlboard[i][j] = 0;
            }

        //Generating White Pieces
        for (int j = 1; j <= 8; j++) {
            board[7][j] = 'P';
            ControlBoard.controlboard[7][j] = 1;
            ControlBoard.controlboard[8][j] = 1;
        }
        board[8][1] = 'R';

        board[8][2] = 'H';

        board[8][3] = 'B';

        board[8][4] = 'K';
        ControlBoard.controlboard[8][4]=11;

        board[8][5] = 'Q';

        board[8][6] = 'B';

        board[8][7] = 'H';

        board[8][8] = 'R';

        //Generating Black Pieces
        for (int j = 1; j <= 8; j++) {
            board[2][j] = 'p';
            ControlBoard.controlboard[2][j] = 2;
            ControlBoard.controlboard[1][j] = 2;
        }
        board[1][1] = 'r';

        board[1][2] = 'h';

        board[1][3] = 'b';

        board[1][4] = 'k';
        ControlBoard.controlboard[1][4]=12;

        board[1][5] = 'q';

        board[1][6] = 'b';

        board[1][7] = 'h';

        board[1][8] = 'r';

    }

    public void boardprint() {
        for (int i = 1; i <= 8; i++) {
            for (int j = 1; j <= 8; j++)
                System.out.print(board[i][j] + "  ");
            System.out.println();

        }

    }


}
