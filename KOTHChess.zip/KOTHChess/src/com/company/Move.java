package com.company;

import Pieces.*;

import java.util.Scanner;

public class Move {
    //public static int control;
    Scanner sc = new Scanner(System.in);


    GraphicBoard printer = new GraphicBoard();
    ControlBoard controller = new ControlBoard();

    public void wmove() {
        System.out.print("Which piece you wish to move?");
        String o = sc.next();
        switch (o) {
            case "P":
                System.out.println("Which white Pawn?");
                Pawn.coordX = sc.nextInt();
                Pawn.coordY = sc.nextInt();


                if (controller.isOccupiedWhite(Pawn.coordX, Pawn.coordY) == false) {
                    System.out.println("There is no white Pawn there.");
                    wmove();
                }

                System.out.println();

                System.out.println("Move to?");
                Pawn.newX = sc.nextInt();
                Pawn.newY = sc.nextInt();
                Pawn p = new Pawn();
                if (p.legalMove() == false) {
                    System.out.println("The piece can't move like that!");
                    wmove();
                } else if (controller.isOccupiedWhite(Pawn.newX, Pawn.newY) == true) {
                    System.out.println("That space is already occupied by a white piece.");
                    wmove();

                } else {
                    ControlBoard.controlboard[Pawn.newX][Pawn.newY] = 1;
                    ControlBoard.controlboard[Pawn.coordX][Pawn.coordY] = 0;
                    GraphicBoard.board[Piece.newX][Piece.newY] = 'P';
                    GraphicBoard.board[Piece.coordX][Piece.coordY] = ' ';
                    printer.boardprint();

                }
                break;
            case "R":
                System.out.println("Which white Rook?");
                Rook.coordX = sc.nextInt();
                Rook.coordY = sc.nextInt();

                controller = new ControlBoard();
                if (controller.isOccupiedWhite(Rook.coordX, Rook.coordY) == false) {
                    System.out.println("There is no white Rook there.");
                    wmove();
                }

                System.out.println();

                System.out.println("Move to?");
                Pawn.newX = sc.nextInt();
                Pawn.newY = sc.nextInt();
                Rook r = new Rook();
                if (r.legalMove() == false) {
                    System.out.println("The piece can't move like that!");
                    wmove();
                } else if (controller.isOccupiedWhite(Rook.newX, Rook.newY) == true) {
                    System.out.println("That space is already occupied by a white piece.");
                    wmove();

                } else {
                    ControlBoard.controlboard[Rook.newX][Rook.newY] = 1;
                    ControlBoard.controlboard[Rook.coordX][Rook.coordY] = 0;
                    GraphicBoard.board[Rook.newX][Rook.newY] = 'R';
                    GraphicBoard.board[Rook.coordX][Rook.coordY] = ' ';

                    printer.boardprint();
                }
                break;
            case "H":
                System.out.println("Which white Knight?");
                Knight.coordX = sc.nextInt();
                Knight.coordY = sc.nextInt();

                controller = new ControlBoard();
                if (controller.isOccupiedWhite(Knight.coordX, Knight.coordY) == false) {
                    System.out.println("There is no white Knight there.");
                    wmove();
                }

                System.out.println();

                System.out.println("Move to?");
                Knight.newX = sc.nextInt();
                Knight.newY = sc.nextInt();
                Knight h = new Knight();
                if (h.legalMove() == false) {
                    System.out.println("The piece can't move like that!");
                    wmove();
                } else if (controller.isOccupiedWhite(Knight.newX, Knight.newY) == true) {
                    System.out.println("That space is already occupied by a white piece.");
                    wmove();

                } else {
                    ControlBoard.controlboard[Knight.newX][Knight.newY] = 1;
                    ControlBoard.controlboard[Knight.coordX][Knight.coordY] = 0;
                    GraphicBoard.board[Knight.newX][Knight.newY] = 'H';
                    GraphicBoard.board[Knight.coordX][Knight.coordY] = ' ';

                    printer.boardprint();
                }
                break;
            case "B":
                System.out.println("Which white Bishop?");
                Bishop.coordX = sc.nextInt();
                Bishop.coordY = sc.nextInt();

                controller = new ControlBoard();
                if (controller.isOccupiedWhite(Bishop.coordX, Bishop.coordY) == false) {
                    System.out.println("There is no white Bishop there.");
                    wmove();
                }

                System.out.println();

                System.out.println("Move to?");
                Bishop.newX = sc.nextInt();
                Bishop.newY = sc.nextInt();
                Bishop b = new Bishop();
                if (b.legalMove() == false) {
                    System.out.println("The piece can't move like that!");
                    wmove();
                } else if (controller.isOccupiedWhite(Bishop.newX, Bishop.newY) == true) {
                    System.out.println("That space is already occupied by a white piece.");
                    wmove();

                } else {
                    ControlBoard.controlboard[Bishop.newX][Bishop.newY] = 1;
                    ControlBoard.controlboard[Bishop.coordX][Bishop.coordY] = 0;
                    GraphicBoard.board[Bishop.newX][Bishop.newY] = 'B';
                    GraphicBoard.board[Bishop.coordX][Bishop.coordY] = ' ';

                    printer.boardprint();
                }
                break;
            case "K":
                System.out.println("Move the white King from:");
                King.coordX = sc.nextInt();
                King.coordY = sc.nextInt();


                if (controller.isOccupiedWKing(King.coordX, King.coordY) == false) {
                    System.out.println("There is no white King there.");
                    wmove();
                }

                System.out.println();

                System.out.println("To:");
                King.newX = sc.nextInt();
                King.newY = sc.nextInt();
                King k = new King();
                if (k.legalMove() == false) {
                    System.out.println("The piece can't move like that!");
                    wmove();
                } else if (controller.isOccupiedWhite(King.newX, King.newY) == true) {
                    System.out.println("That space is already occupied by a white piece.");
                    wmove();

                } else {
                    ControlBoard.controlboard[King.newX][King.newY] = 11;
                    ControlBoard.controlboard[King.coordX][King.coordY] = 0;
                    GraphicBoard.board[King.newX][King.newY] = 'K';
                    GraphicBoard.board[King.coordX][King.coordY] = ' ';

                    printer.boardprint();
                }
                break;
            case "Q":
                System.out.println("Move the white Queen from:");
                Queen.coordX = sc.nextInt();
                Queen.coordY = sc.nextInt();


                if (controller.isOccupiedWhite(Queen.coordX, Queen.coordY) == false) {
                    System.out.println("There is no white Queen there.");
                    wmove();
                }

                System.out.println();

                System.out.println("To:");
                King.newX = sc.nextInt();
                King.newY = sc.nextInt();
                Queen q = new Queen();
                if (q.legalMove() == false) {
                    System.out.println("The piece can't move like that!");
                    wmove();
                } else if (controller.isOccupiedWhite(Queen.newX, Queen.newY) == true) {
                    System.out.println("That space is already occupied by a white piece.");
                    wmove();

                } else {
                    ControlBoard.controlboard[Queen.newX][Queen.newY] = 1;
                    ControlBoard.controlboard[Queen.coordX][Queen.coordY] = 0;
                    GraphicBoard.board[Queen.newX][Queen.newY] = 'Q';
                    GraphicBoard.board[Queen.coordX][Queen.coordY] = ' ';

                    printer.boardprint();
                }
                break;


            default: {
                System.out.println("Invalid input.");
                wmove();
            }
        }


    }
    public void bmove() {
        System.out.print("Which piece you wish to move?");
        String o = sc.next();
        switch (o) {
            case "p":
                System.out.println("Which black Pawn?");
                Pawn.coordX = sc.nextInt();
                Pawn.coordY = sc.nextInt();


                if (controller.isOccupiedBlack(Pawn.coordX, Pawn.coordY) == false) {
                    System.out.println("There is no black Pawn there.");
                    bmove();
                }

                System.out.println();

                System.out.println("Move to?");
                Pawn.newX = sc.nextInt();
                Pawn.newY = sc.nextInt();
                Pawn p = new Pawn();
                if (p.legalMove() == false) {
                    System.out.println("The piece can't move like that!");
                    bmove();
                } else if (controller.isOccupiedBlack(Pawn.newX, Pawn.newY) == true) {
                    System.out.println("That space is already occupied by a black piece.");
                    bmove();

                } else {
                    ControlBoard.controlboard[Pawn.newX][Pawn.newY] = 2;
                    ControlBoard.controlboard[Pawn.coordX][Pawn.coordY] = 0;
                    GraphicBoard.board[Piece.newX][Piece.newY] = 'p';
                    GraphicBoard.board[Piece.coordX][Piece.coordY] = ' ';
                    printer.boardprint();

                }
                break;
            case "r":
                System.out.println("Which black Rook?");
                Rook.coordX = sc.nextInt();
                Rook.coordY = sc.nextInt();

                controller = new ControlBoard();
                if (controller.isOccupiedBlack(Rook.coordX, Rook.coordY) == false) {
                    System.out.println("There is no black Rook there.");
                    bmove();
                }

                System.out.println();

                System.out.println("Move to?");
                Pawn.newX = sc.nextInt();
                Pawn.newY = sc.nextInt();
                Rook r = new Rook();
                if (r.legalMove() == false) {
                    System.out.println("The piece can't move like that!");
                    bmove();
                } else if (controller.isOccupiedBlack(Rook.newX, Rook.newY) == true) {
                    System.out.println("That space is already occupied by a black piece.");
                    bmove();

                } else {
                    ControlBoard.controlboard[Rook.newX][Rook.newY] = 2;
                    ControlBoard.controlboard[Rook.coordX][Rook.coordY] = 0;
                    GraphicBoard.board[Rook.newX][Rook.newY] = 'r';
                    GraphicBoard.board[Rook.coordX][Rook.coordY] = ' ';

                    printer.boardprint();
                }
                break;
            case "h":
                System.out.println("Which black Knight?");
                Knight.coordX = sc.nextInt();
                Knight.coordY = sc.nextInt();

                controller = new ControlBoard();
                if (controller.isOccupiedBlack(Knight.coordX, Knight.coordY) == false) {
                    System.out.println("There is no black Knight there.");
                    bmove();
                }

                System.out.println();

                System.out.println("Move to?");
                Knight.newX = sc.nextInt();
                Knight.newY = sc.nextInt();
                Knight h = new Knight();
                if (h.legalMove() == false) {
                    System.out.println("The piece can't move like that!");
                    bmove();
                } else if (controller.isOccupiedBlack(Knight.newX, Knight.newY) == true) {
                    System.out.println("That space is already occupied by a black piece.");
                    bmove();

                } else {
                    ControlBoard.controlboard[Knight.newX][Knight.newY] = 2;
                    ControlBoard.controlboard[Knight.coordX][Knight.coordY] = 0;
                    GraphicBoard.board[Knight.newX][Knight.newY] = 'h';
                    GraphicBoard.board[Knight.coordX][Knight.coordY] = ' ';

                    printer.boardprint();
                }
                break;
            case "b":
                System.out.println("Which black Bishop?");
                Bishop.coordX = sc.nextInt();
                Bishop.coordY = sc.nextInt();

                controller = new ControlBoard();
                if (controller.isOccupiedBlack(Bishop.coordX, Bishop.coordY) == false) {
                    System.out.println("There is no black Bishop there.");
                    bmove();
                }

                System.out.println();

                System.out.println("Move to?");
                Bishop.newX = sc.nextInt();
                Bishop.newY = sc.nextInt();
                Bishop b = new Bishop();
                if (b.legalMove() == false) {
                    System.out.println("The piece can't move like that!");
                    bmove();
                } else if (controller.isOccupiedBlack(Bishop.newX, Bishop.newY) == true) {
                    System.out.println("That space is already occupied by a black piece.");
                    bmove();

                } else {
                    ControlBoard.controlboard[Bishop.newX][Bishop.newY] = 2;
                    ControlBoard.controlboard[Bishop.coordX][Bishop.coordY] = 0;
                    GraphicBoard.board[Bishop.newX][Bishop.newY] = 'b';
                    GraphicBoard.board[Bishop.coordX][Bishop.coordY] = ' ';

                    printer.boardprint();
                }
                break;
            case "k":
                System.out.println("Move the black King from:");
                King.coordX = sc.nextInt();
                King.coordY = sc.nextInt();


                if (controller.isOccupiedBKing(King.coordX, King.coordY) == false) {
                    System.out.println("There is no black King there.");
                    bmove();
                }

                System.out.println();

                System.out.println("To:");
                King.newX = sc.nextInt();
                King.newY = sc.nextInt();
                King k = new King();
                if (k.legalMove() == false) {
                    System.out.println("The piece can't move like that!");
                    bmove();
                } else if (controller.isOccupiedBlack(King.newX, King.newY) == true) {
                    System.out.println("That space is already occupied by a black piece.");
                    bmove();

                } else {
                    ControlBoard.controlboard[King.newX][King.newY] = 12;
                    ControlBoard.controlboard[King.coordX][King.coordY] = 0;
                    GraphicBoard.board[King.newX][King.newY] = 'k';
                    GraphicBoard.board[King.coordX][King.coordY] = ' ';

                    printer.boardprint();
                }
                break;
            case "q":
                System.out.println("Move the black Queen from:");
                Queen.coordX = sc.nextInt();
                Queen.coordY = sc.nextInt();


                if (controller.isOccupiedBlack(Queen.coordX, Queen.coordY) == false) {
                    System.out.println("There is no black Queen there.");
                    bmove();
                }

                System.out.println();

                System.out.println("To:");
                King.newX = sc.nextInt();
                King.newY = sc.nextInt();
                Queen q = new Queen();
                if (q.legalMove() == false) {
                    System.out.println("The piece can't move like that!");
                    bmove();
                } else if (controller.isOccupiedBlack(Queen.newX, Queen.newY) == true) {
                    System.out.println("That space is already occupied by a black piece.");
                    bmove();

                } else {
                    ControlBoard.controlboard[Queen.newX][Queen.newY] = 2;
                    ControlBoard.controlboard[Queen.coordX][Queen.coordY] = 0;
                    GraphicBoard.board[Queen.newX][Queen.newY] = 'q';
                    GraphicBoard.board[Queen.coordX][Queen.coordY] = ' ';

                    printer.boardprint();
                }
                break;


            default: {
                System.out.println("Invalid input.");
                bmove();
            }
        }
    }
}


