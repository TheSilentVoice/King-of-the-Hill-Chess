package com.company;

public class ControlBoard {


    public static int[][] controlboard = new int[10][10];

    public boolean isOccupiedWhite(int x, int y) {
        if (controlboard[x][y] == 1)
            return true;
        else
            return false;

    }
    public boolean isOccupiedWKing(int x,int y){
        if(controlboard[x][y]==11)
            return true;
        else
            return false;
    }

    public boolean isOccupiedBlack(int x, int y) {
        if (controlboard[x][y] == 2)
            return true;
        else
            return false;
    }
    public boolean isOccupiedBKing(int x,int y){
        if(controlboard[x][y]==12)
            return true;
        else
            return false;
    }

    public boolean isEmpty(int x, int y) {
        if (controlboard[x][y] == 0)
            return true;
        else
            return false;
    }

    public void boardprint() {
        for (int i = 1; i <= 8; i++) {
            for (int j = 1; j <= 8; j++)
                System.out.print(controlboard[i][j] + "  ");
            System.out.println();
        }
    }
}