package com.company;

import Pieces.King;
import com.company.Move;
import com.company.Game;

import java.util.Scanner;


public class Turn {

    String end;
    Game newgame = new Game();
    Move m = new Move();
    int color = 1;
    Scanner kk = new Scanner(System.in);
    public int kingStatus;

    public void turn() {


        while (1 < 2) {
            if (color == 1) {
                m.wmove();
                gamestate();
                System.out.println("White moved, Black moves next.");
                color = 2;


            } else {
                m.bmove();
                gamestate();
                System.out.println("Black moved, White moves next.");
                color = 1;
            }


        }

    }

    void gamestate() {
        if ((ControlBoard.controlboard[ == 11 || ControlBoard.controlboard[4][5] == 11 || ControlBoard.controlboard[5][4] == 11 || ControlBoard.controlboard[5][5] == 11)||BkingAlive()==false) {

            System.out.println("White wins!");4][4]
            end = kk.next();
            System.out.println("Play again? Y/N");
            switch (end) {
                case "Y" -> newgame.gamestart();
                case "N" -> {
                    System.out.println("Thanks for playing!");
                    System.exit(0);
                }
                default -> System.out.println("?????");

            }
        }


        if ((ControlBoard.controlboard[4][4] == 12 || ControlBoard.controlboard[4][5] == 12 || ControlBoard.controlboard[5][4] == 12 || ControlBoard.controlboard[5][5] == 12)||(WkingAlive()==false)) {


            System.out.println("Black wins!");
            end = kk.next();
            System.out.println("Play again? Y/N");
            switch (end) {
                case "Y" -> newgame.gamestart();
                case "N" -> {
                    System.out.println("Thanks for playing!");
                    System.exit(0);
                }
                default -> System.out.println("?????");
            }

        }

    }
    boolean WkingAlive(){

        for(int i=1;i<=8;i++)
            for(int j=1;j<=8;j++)
                if(ControlBoard.controlboard[i][j]==11)
                    kingStatus=1;

                if(kingStatus==0)
                    return false;
                else
                    return true;

    }
    boolean BkingAlive(){

        for(int i=1;i<=8;i++)
            for(int j=1;j<=8;j++)
                if(ControlBoard.controlboard[i][j]==12)
                    kingStatus=1;

        if(kingStatus==0)
            return false;
        else
            return true;

    }


}

